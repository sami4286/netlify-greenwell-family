$("#lightgallery").lightGallery({thumbnail: true});

$(".tour-slider").not('.slick-initialized').slick({dots: true, infinite: true, autoplay: true, autoplaySpeed: 3000,
variableWidth: true, centerPadding: "20px", centerMode: true, prevArrow: false, nextArrow: false});